
//using express to create easily a http server
const express=require('express');
const app=express();
app.get('/',(req,res)=>{
	res.header('Content-Type','application/json');
	res.send(JSON.stringify(data));
});


//module to parse the body 
 const parser =require('body-parser');
 app.use(parser.json());

//use cors so client and server can communicate and in case that client came by other server
const cors =require('cors');
app.use(cors());

//RESTFULL API
app.listen(2001); //this server listen on 2001 port 


//use sqlite3 as database
const sqlite3 =require('sqlite3').verbose();
const db = new sqlite3.Database('books.sqlite');

 
 /* 
 	create a post for book-entry
 */
app.post('/books', (req,res)=>{
    const book= req.body;
  //query for instert in sqlite3 database
   const q=`insert into books ('author','title','genre','price') values ('${book.author}', '${book.title}', '${book.genre}','${book.price}') `;
   db.run(q,(err)=>{
   	  if (err) 
   	  {
   	  	res.send('Error executing query about books');
   	  }

   });


   
});


/*
  Create a get for book-search
*/
app.get('/books/:keyword',(req,res)=> {
	const q=`SELECT * FROM books WHERE title LIKE '%${req.params.keyword}%'`;

	db.all(q,async (err,rows)=>{
  		try {
			const rows = await query(q);
			//send back response 
			res.send(JSON.stringify(rows));

		}catch(err){
			res.send('Error executing query about keyword search');
		}
	});
});

/*create a function for our query using promises*/
function   query(q){
	return new Promise((resolve,reject)=>{
 		db.all(q,(err,rows)=>{
 			if(err){
				reject(err);
			}else{
				resolve(rows);
			}

		});	
	});
}




